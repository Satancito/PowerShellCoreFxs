$ErrorActionPreference = "Stop"
#region Const
#endregion Consts


#region Vars
#Warning!!! Only change with correct value.
Set-Variable -Name "XSourceUrlRepository" -Value "$([System.Environment]::GetEnvironmentVariable("XSourceUrlRepository", [System.EnvironmentVariableTarget]::User))" -Scope Global

#endregion Vars

    


